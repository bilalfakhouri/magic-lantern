-- Hello, World!
-- Prints 'Hello World' on the console

menu.close()
console.show()
print "Hello, World!"
print "Press SET to exit."
key.wait(KEY.SET)
console.hide()

